<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\ScrapingModel;

class Home extends BaseController
{
    public function index(): string
    {

        // Ambil data dari input link dan ubah spasi menjadi underscore
        $link = str_replace(' ', '_', $this->request->getPost('link'));

        // Panggil model
        $model = new ScrapingModel();
        $data = $model->scrapeData($link);
        $title = "Teknopedia - Ensiklopedia Dunia";

        return view('templates/header',  ['title' => $title])
            // . view('templates/search')
            . view('templates/main', $data)
            . view('templates/footer');
    }
}
