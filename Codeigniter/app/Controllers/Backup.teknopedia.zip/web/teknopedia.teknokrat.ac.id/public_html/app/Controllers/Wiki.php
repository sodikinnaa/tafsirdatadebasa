<?php
// app/Controllers/Wiki.php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\WikiModel;

class Wiki extends Controller
{
    public function view($link)
    {
        // Panggil model WikiModel
        $model = new WikiModel();

        // Ambil data dari model berdasarkan link
        $data = $model->scrapeData($link);

        $title = $data['title'];

        

        return view('templates/header', ['title' => $title])
        // . view('templates/search')
        . view('templates/main', $data)
        . view('templates/footer');
    }

    public function custom()
    {
         // Panggil model WikiModel
         $model = new WikiModel();
         $kosong = $model->Kosong();
         $title = $kosong['title'];

        return view('templates/header', ['title' => $title])
        // . view('templates/search')
        . view('templates/main', $kosong)
        . view('errors/cli/eror_custom')
        . view('templates/footer');
         // Ganti 'home' dengan nama view beranda Anda.
    }    

    

    


}
