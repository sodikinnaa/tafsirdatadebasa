<?php

namespace App\Models;

use CodeIgniter\Model;
use Goutte\Client;

class ScrapingModel extends Model
{
    public function scrapeData($link)
    {
        $client = new Client();
        $url = "https://id.wikipedia.org/wiki/" . $link;

        $crawler = $client->request('GET', $url);

        if ($client->getResponse()->getStatusCode() == 200) {
            $titleNode = $crawler->filter('h1#firstHeading span');
            if ($titleNode->count() > 0) {
                $title = $titleNode->text();
            } else {
                $title = "Title not found";
            }

            $contentNode = $crawler->filter('div#bodyContent');
            if ($contentNode->count() > 0) {
                $content = $contentNode->html();
                $content = $this->removeEditSections($content);
            } else {
                $content = "Content not found";
            }

            $data = [
                'title' => $title,
                'content' => $content,
            ];

            return $data;
        } else {
            return [
                'title' => 'Gagal mengambil halaman',
                'content' => 'Kode status HTTP: ' . $client->getResponse()->getStatusCode(),
            ];
        }
    }

    private function removeEditSections($html)
    {
        $dom = new \DOMDocument();
        libxml_use_internal_errors(true);
        $dom->loadHTML($html);
        libxml_use_internal_errors(false);

        $xpath = new \DOMXPath($dom);

        // Hapus div span dengan class "mp-footer"
        $editSections = $xpath->query('//div[contains(@class, "mp-footer")]');
        foreach ($editSections as $editSection) {
            $editSection->parentNode->removeChild($editSection);
        }

        // Hapus tag div class "vector-dropdown mw-portlet mw-portlet-lang"
        $editsction2 = $xpath->query('//div[contains(@class, "vector-dropdown mw-portlet mw-portlet-lang")]');
        foreach ($editsction2 as $editsction29) {
            $editsction29->parentNode->removeChild($editsction29);
        }

        $editsction3 = $xpath->query('//div[contains(@id, "atas")]');
        foreach ($editsction3 as $editsction3) {
            $editsction3->parentNode->removeChild($editsction3);
        }

        // hapus div calss ="printfooter"
        $editsctiona = $xpath->query('//div[contains(@class, "row")]');
        foreach ($editsctiona as $editsction6) {
            $editsction6->parentNode->removeChild($editsction6);
        }

        // hapus div calss ="printfooter"
        $editsction4 = $xpath->query('//div[contains(@class, "printfooter")]');
        foreach ($editsction4 as $editsction4) {
            $editsction4->parentNode->removeChild($editsction4);
        }

        // hapus id calass = "noprint"
        $editsction5 = $xpath->query('//div[contains(@class, "noprint")]');
        foreach ($editsction5 as $editsction5) {
            $editsction5->parentNode->removeChild($editsction5);
        }
        return $dom->saveHTML();
    }
}

