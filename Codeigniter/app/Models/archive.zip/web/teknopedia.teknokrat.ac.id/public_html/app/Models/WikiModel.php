<?php
// app/Models/WikiModel.php

namespace App\Models;

use Goutte\Client;

class WikiModel
{
    public function scrapeData($link)
    {
        $client = new Client();
        $url = "https://id.wikipedia.org/wiki/" . $link;

        $crawler = $client->request('GET', $url);

        if ($client->getResponse()->getStatusCode() == 200) {
            // Anda dapat menyesuaikan elemen HTML yang ingin Anda scrape di sini
            $titleNode = $crawler->filter('h1#firstHeading span');
            $contentNode = $crawler->filter('div#bodyContent ');

            // Menghapus tag span dengan class "mw-editsection" dari konten
            $contentHtml = $contentNode->html();
            $contentHtml = $this->removeEditSections($contentHtml);

            $data = [
                'title' => $titleNode->text(),
                'content' => $contentHtml,
            ];

            return $data;
        } else {
            return $this->newscrapeData($link);
            /*return [
                'title' => 'Gagal mengambil halaman',
                'content' => 'Kode status HTTP: ' . $client->getResponse()->getStatusCode(),
            ];*/
        }
    }

    // Fungsi untuk menghapus tag span dengan class "mw-editsection"
    private function removeEditSections($html)
    {
        $dom = new \DOMDocument();
        libxml_use_internal_errors(true);
        $dom->loadHTML($html);
        libxml_use_internal_errors(false);

        $xpath = new \DOMXPath($dom);
        $editsctiona = $xpath->query('//div[contains(@class, "metadata plainlinks")]');
        foreach ($editsctiona as $editsction6) {
            $editsction6->parentNode->removeChild($editsction6);
        }
        // Hapus tag span dengan class "mw-editsection"
        $editSections = $xpath->query('//span[contains(@class, "mw-editsection")]');
        foreach ($editSections as $editSection) {
            $editSection->parentNode->removeChild($editSection);
        }

        // Hapus elemen dengan class "vector-body-before-content"
        $vectorBodyBeforeContent = $xpath->query('//div[contains(@class, "vector-body-before-content")]');
        foreach ($vectorBodyBeforeContent as $beforeContent) {
            $beforeContent->parentNode->removeChild($beforeContent);
        }
        
        $editsctionb = $xpath->query('//div[contains(@class, "oo-ui-fieldLayout-field")]');
        foreach ($editsctionb as $editsction7) {
            $editsction7->parentNode->removeChild($editsction7);
        }

        // hapus class dengan elemen box-Cleanup plainlinks metadata ambox ambox-style ambox-Cleanup
        // $boxCleanup = $xpath->query('//div[contains(@class, "box-Cleanup plainlinks metadata ambox ambox-style ambox-Cleanup")]');
        // foreach ($boxCleanup as $edtcontent) {
        //     $edtcontent->parentNode->removeChild($edtcontent);
        
        // hapus div calss ="printfooter"
        $editsction4 = $xpath->query('//div[contains(@class, "printfooter")]');
        foreach ($editsction4 as $editsction4) {
            $editsction4->parentNode->removeChild($editsction4);
        }

        // hapus id calass = "noprint"
        $editsction5 = $xpath->query('//div[contains(@class, "noprint")]');
        foreach ($editsction5 as $editsction5) {
            $editsction5->parentNode->removeChild($editsction5);
        }
        
        $editsction6 = $xpath->query('//span[contains(@class, "mw-valign-text-top")]');
        foreach ($editsction6 as $editsction6) {
            $editsction6->parentNode->removeChild($editsction6);
        }
                $editsctionc = $xpath->query('//div[contains(@class, "mw-pager-navigation-bar")]');
        foreach ($editsctionc as $editsction8) {
            $editsction8->parentNode->removeChild($editsction8);
        }
        
        return $dom->saveHTML();
    }


    public function newscrapeData($link)
    {
        $client = new Client();
        $url = "https://id.wikipedia.org/w/index.php?search=" . $link;

        $crawler = $client->request('GET', $url);

        if ($client->getResponse()->getStatusCode() == 200) {
            // Anda dapat menyesuaikan elemen HTML yang ingin Anda scrape di sini
            $titleNode = $crawler->filter('h1#firstHeading');
            $contentNode = $crawler->filter('ul.mw-search-results');

            $data = [
                'title' => $titleNode->text(),
                'content' => $contentNode->html(),
            ];

            return $data;
        } else {
            return [
                'title' => 'Gagal mengambil halaman',
                'content' => 'Kode status HTTP: ' . $client->getResponse()->getStatusCode(),
            ];
        }
    }

    public function Kosong()
    {
        $custom = [
            'title' => 'Judul Kosong',
            'content' => 'Kosong',
        ];

        return $custom;
    }
}


